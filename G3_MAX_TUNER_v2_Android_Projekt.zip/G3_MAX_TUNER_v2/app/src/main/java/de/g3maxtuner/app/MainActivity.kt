package de.g3maxtuner.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private var scanner: BluetoothLeScanner? = null
    private val found = linkedSetOf<String>()
    private val handler = Handler(Looper.getMainLooper())

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            runOnUiThread {
                val device = result.device
                val name = try {
                    device.name ?: "Unbenanntes BLE-Gerät"
                } catch (_: SecurityException) {
                    "BLE-Gerät (Name nicht verfügbar)"
                }
                val key = "${device.address}|$name"
                if (found.add(key)) {
                    val item = TextView(this@MainActivity).apply {
                        text = "$name\nSignal: ${result.rssi} dBm\nAdresse: ${device.address}"
                        textSize = 14f
                        setTextColor(Color.WHITE)
                        setPadding(14, 14, 14, 14)
                        setBackgroundColor(Color.rgb(30, 39, 54))
                    }
                    results.addView(item)
                }
            }
        }

        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { status.text = "Scan fehlgeschlagen (Code $errorCode)" }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 34, 22, 22)
            setBackgroundColor(Color.rgb(12, 16, 24))
        }
        fun label(s: String, size: Float, color: Int, bold: Boolean = false) =
            TextView(this).apply {
                text = s; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }

        page.addView(label("G3 MAX TUNER", 27f, Color.WHITE, true))
        page.addView(label("BLUETOOTH SCANNER • READ-ONLY", 12f, Color.rgb(0, 210, 180), true))
        status = label("Bereit für die Suche", 14f, Color.WHITE)
        page.addView(status)

        val scanButton = Button(this).apply {
            text = "BLUETOOTH-GERÄTE SUCHEN"
            setOnClickListener { checkPermissionsAndScan() }
        }
        page.addView(scanButton)

        val stopButton = Button(this).apply {
            text = "SCAN STOPPEN"
            setOnClickListener { stopScan("Suche gestoppt") }
        }
        page.addView(stopButton)

        page.addView(label("GEFUNDENE GERÄTE", 15f, Color.WHITE, true))
        results = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = ScrollView(this)
        scroll.addView(results)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        page.addView(label(
            "Hinweis: Die App sucht nur nach sichtbaren Bluetooth-LE-Geräten. " +
            "Ein angezeigter Treffer bestätigt noch keine MAX-G3-Kompatibilität. " +
            "Es werden keine Fahrparameter oder Firmware-Einstellungen verändert.",
            12f, Color.LTGRAY
        ))
        setContentView(page)
    }

    private fun requiredPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun checkPermissionsAndScan() {
        val missing = requiredPermissions().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 41)
        } else {
            startScan()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startScan()
        } else if (requestCode == 41) {
            status.text = "Bluetooth-Berechtigung wurde nicht erteilt"
        }
    }

    private fun startScan() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter? = manager.adapter
        if (adapter == null || !adapter.isEnabled) {
            status.text = "Bitte Bluetooth in den Android-Einstellungen einschalten"
            return
        }
        try {
            scanner = adapter.bluetoothLeScanner
            if (scanner == null) {
                status.text = "Bluetooth-LE-Scanner nicht verfügbar"
                return
            }
            found.clear()
            results.removeAllViews()
            scanner?.startScan(scanCallback)
            status.text = "Suche läuft – Scooter einschalten und in der Nähe lassen"
            handler.postDelayed({ stopScan("Suche beendet") }, 12_000)
        } catch (_: SecurityException) {
            status.text = "Keine Berechtigung zum Bluetooth-Scan"
        }
    }

    private fun stopScan(message: String) {
        try { scanner?.stopScan(scanCallback) } catch (_: SecurityException) { }
        status.text = message
    }

    override fun onDestroy() {
        stopScan("App geschlossen")
        super.onDestroy()
    }
}
