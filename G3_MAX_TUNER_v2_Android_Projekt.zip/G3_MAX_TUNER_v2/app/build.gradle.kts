plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "de.g3maxtuner.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "de.g3maxtuner.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
