# G3 MAX TUNER

Android-Studio-Projekt für eine Dashboard-/Diagnose-App im Demo-Modus.

## Öffnen
1. ZIP entpacken.
2. Den Ordner `G3_MAX_TUNER` in Android Studio öffnen.
3. Gradle-Synchronisierung abwarten.
4. Über **Run** auf einem Android-Gerät oder Emulator starten.

## Aktueller Stand
- Dashboard-Oberfläche
- Statusanzeige
- Platzhalter für Geschwindigkeit, Akku und Temperatur
- Demo-Schaltflächen für Verbindung und Diagnose

## Wichtig
Diese Version stellt **noch keine echte Bluetooth-Verbindung** zum Segway Ninebot MAX G3 her.
Sie liest keine Scooter-Daten aus und verändert keine Firmware oder Motorparameter.
Für eine echte Diagnose-Anbindung muss zuerst ein dokumentiertes und kompatibles BLE-Protokoll
für genau das Scooter-Modell verifiziert werden. Keine Firmware-Manipulation oder Umgehung
von Sicherheitsbegrenzungen ist enthalten.
