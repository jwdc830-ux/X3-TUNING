package de.g3maxtuner.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 16, 24)
    private val panel = Color.rgb(25, 32, 45)
    private val accent = Color.rgb(0, 210, 180)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(bg)
            gravity = Gravity.TOP
        }

        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            }

        page.addView(text("G3 MAX TUNER", 28f, Color.WHITE, true))
        page.addView(text("SEGWAY • DASHBOARD", 12f, accent, true))

        val status = TextView(this).apply {
            text = "NICHT VERBUNDEN"
            textSize = 13f
            setTextColor(accent)
            setPadding(16, 14, 16, 14)
            setBackgroundColor(panel)
        }
        page.addView(status)

        val speedCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(panel)
        }
        speedCard.addView(text("GESCHWINDIGKEIT", 12f, Color.LTGRAY, true))
        speedCard.addView(text("-- km/h", 42f, Color.WHITE, true))
        speedCard.addView(text("Live-Daten erscheinen nach einer unterstützten Verbindung.", 13f, Color.LTGRAY))
        val cardParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 22 }
        page.addView(speedCard, cardParams)

        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 18, 0, 0)
        }
        fun stat(label: String, value: String): LinearLayout =
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 16, 16, 16)
                setBackgroundColor(panel)
                addView(text(label, 11f, Color.LTGRAY, true))
                addView(text(value, 22f, Color.WHITE, true))
            }
        val battery = stat("AKKU", "-- %")
        val temp = stat("TEMPERATUR", "-- °C")
        stats.addView(battery, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 8 })
        stats.addView(temp, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = 8 })
        page.addView(stats)

        val connect = Button(this).apply {
            text = "SCOOTER VERBINDEN"
            setOnClickListener {
                status.text = "DEMO-MODUS • NOCH KEINE VERBINDUNG"
            }
        }
        page.addView(connect, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })

        val diagnose = Button(this).apply {
            text = "DIAGNOSE"
            setOnClickListener {
                status.text = "DIAGNOSE: BLE-SCHNITTSTELLE NOCH NICHT IMPLEMENTIERT"
            }
        }
        page.addView(diagnose, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })

        page.addView(text(
            "Hinweis: Dies ist ein sicheres UI-Grundgerüst im Demo-Modus. " +
            "Es verändert keine Firmware, Motorleistung oder Geschwindigkeitsbegrenzung. " +
            "Eine echte G3-MAX-Verbindung benötigt ein verifiziertes, unterstütztes BLE-Protokoll.",
            12f, Color.LTGRAY
        ).apply { setPadding(2, 24, 2, 0) })

        setContentView(page)
    }
}
